package individuo;

public abstract class Gen {

	Object bit;

	//abstract public void muta ();

	abstract Gen clone_aux();

	public abstract Object toInt();

	public Gen clone() {
		Gen unGen = clone_aux();
		return unGen;
	}
	abstract public boolean equals(Gen g2);

}
