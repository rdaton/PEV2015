package logica;

public class Calculadora {

	public static int tamGen (double min, double max, double prec) {
//		double unNumero = (double) 1 + ((double) (max-min) / (double) prec);
//		unNumero = Math.log(unNumero) / Math.log(2);
//		return (int) Math.ceil(unNumero);
		return ((Double) max).intValue() - ((Double) min).intValue()+1;
	}
	
	public static int dameRandom(int a, int b)
	{
		return a + (int)(Math.random() * ((b - a) + 1));
	}

}
