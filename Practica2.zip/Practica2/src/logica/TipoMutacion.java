package logica;

public enum TipoMutacion {
	INSERCI�N, INTERCAMBIO, INVERSI�N, HEUR�STICA, PROPIO;
	public String toString() {
		switch (this) {
		case INSERCI�N:
			return "INSERCI�N";
		case INTERCAMBIO:
			return "INTERCAMBIO";
		case INVERSI�N:
			return "INVERSI�N";
		case HEUR�STICA:
			return "HEUR�STICA";
		case PROPIO:
			return "PROPIO";
		default:
			return "INSERCI�N";
		}
	}

}